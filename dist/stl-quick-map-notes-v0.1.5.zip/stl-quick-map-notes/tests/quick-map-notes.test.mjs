import test from 'node:test';
import assert from 'node:assert/strict';

const listeners = new Map();
globalThis.Hooks = {
  once(name, cb) {listeners.set(name, cb);},
  on(name, cb) {listeners.set(name, cb);}
};
const players = [
  {id:'p-1',isGM:false,name:'Player One'},
  {id:'p-2',isGM:false,name:'Player Two'},
  {id:'g-1',isGM:true,name:'GM'}
];
const journalMap = new Map();
const settings = new Map();
let createCalls = 0;
let lastJournalData = null;
let lastPageData = null;
let createdPages = 0;
let issuedNote = null;
let noteShouldFail = false;
let uploadCalls = [];
const scene = {
  id: 'scene-123', name: 'Maryland Heights',
  async createEmbeddedDocuments(kind,data) {
    assert.equal(kind,'Note');
    if(noteShouldFail) throw Error('Scene rejected note');
    issuedNote = data[0];
    return [{id:'note1',...issuedNote}];
  }
};

globalThis.game = {
  user:{isGM:true},
  users:players,
  journal: {
    get(id){return journalMap.get(id);},
    [Symbol.iterator](){return journalMap.values();}
  },
  settings: {
    register(key,name,opts){settings.set(`${key}:${name}`,opts.default);},
    get(key,name){return settings.get(`${key}:${name}`);},
    async set(key,name,value){settings.set(`${key}:${name}`,value);}
  }
};
globalThis.CONST={JOURNAL_ENTRY_PAGE_FORMATS:{HTML:1}};
globalThis.CONFIG={queries:{}};
globalThis.foundry={
  utils:{randomID(){return 'Abc12345';}},
  applications:{
    api:{DialogV2:{async input(){return null;}}},
    apps:{
      FilePicker:{
        async uploadPersistent(...args) {
          uploadCalls.push(args);
          return {path:`storage/stl-quick-map-notes/${args[2].name}`};
        }
      }
    }
  }
};
globalThis.JournalEntry={
  async create(data){
    createCalls++;lastJournalData=data;
    const id=`newjournal${createCalls}`;
    const j={id,name:data.name,folder:data.folder,ownership:data.ownership,flags:data.flags,
      pages:(data.pages??[]).map((p,i)=>({id:`newpage${createCalls}-${i}`,...p})),
      async createEmbeddedDocuments(kind,pageData) {
        assert.equal(kind,'JournalEntryPage');
        const pages=pageData.map(data=>({id:`added-page${++createdPages}`,...data}));
        lastPageData=pageData[0];
        this.pages.push(...pages);
        return pages;
      }};
    journalMap.set(id,j);
    return j;
  }
};
globalThis.ui={notifications:{info(){},error(){},warn(){}}};
globalThis.canvas={scene,ready:true,dimensions:{sceneRect:{x:0,y:0,width:500,height:500}}};

const {ICONS,escapeHtml,journalHtml,hexColor,buildOwnership,buildPlayerOwnership,makeNoteData,createQuickMapNote,uploadNewIcon, isModuleSuppliedJournal, isRulesReferenceName, isRulesReferenceJournal, buildJournalOptions,playerIconValid,validatePlayerNoteRequest,encodePlayerImage,decodePlayerImage,submitPlayerNoteRequest,verifyPlayerNoteQuery,handlePlayerNoteQuery,ensurePlayerMapNotesFolder,findPlayerMapJournal} = await import('../scripts/main.mjs');

const baseForm = ()=>({
  title:'Old Warehouse',description:'Possible <danger> & clues',
  existingJournal:'',visibility:'gm',iconPreset:ICONS[0][1],
  iconSize:'40',tint:'#edab12',applyTint:true,globallyVisible:false
});

test('Foundry 14 hook registers one button for players and GMs in Token Controls, not Journal Notes',()=>{
  assert.equal(typeof listeners.get('init'),'function');
  listeners.get('init')();
  const controls={
    tokens:{tools:{select:{order:1},target:{order:2}}},
    notes:{tools:{select:{order:1},create:{order:2}}}
  };
  listeners.get('getSceneControlButtons')(controls);
  assert.equal(controls.tokens.tools.stlQuickMapNote.button,true);
  assert.equal(controls.tokens.tools.stlQuickMapNote.order,3);
  assert.equal(controls.tokens.tools.stlQuickMapNote.visible,true);
  assert.equal(controls.tokens.tools.stlQuickMapNote.title,'Quick Map Note');
  assert.equal(controls.notes.tools.stlQuickMapNote,undefined);
  game.user.isGM=false;
  const controls2={tokens:{tools:{select:{order:1}}},notes:{tools:{select:{order:1}}}};
  listeners.get('getSceneControlButtons')(controls2);
  assert.equal(controls2.tokens.tools.stlQuickMapNote.button,true);
  game.user.isGM=true;
});

test('control hook tolerates unavailable Token Controls without altering Journal Notes',()=>{
  const controls={notes:{tools:{select:{order:1}}}};
  listeners.get('getSceneControlButtons')(controls);
  assert.deepEqual(Object.keys(controls.notes.tools),['select']);
});

test('GM-only, limited, observer and selected player ownership',()=>{
  assert.deepEqual(buildOwnership('gm',{},players),{default:0});
  assert.deepEqual(buildOwnership('pin',{},players),{default:1});
  assert.deepEqual(buildOwnership('read',{},players),{default:2});
  assert.deepEqual(buildOwnership('specific',{'p-1':'1','p-2':'2','g-1':'2'},players),
    {default:0,'p-1':1,'p-2':2});
  assert.deepEqual(buildOwnership('unknown',{},players),{default:0});
});

test('escape HTML in new Journal text and normalize color',()=>{
  assert.equal(escapeHtml('<b>"&\'</b>'), '&lt;b&gt;&quot;&amp;&#39;&lt;/b&gt;');
  assert.equal(journalHtml('Hello <GM>\nNext'),'<p>Hello &lt;GM&gt;<br>Next</p>');
  assert.equal(hexColor('not-a-color'),'#FFFFFF');
  assert.equal(hexColor('#abcdef'),'#ABCDEF');
});

test('native Note payload stores icon src/tint, size, fog and Journal references',()=>{
  const n=makeNoteData({x:10.6,y:20.2,title:'Warehouse',journalId:'a',pageId:'b',
    icon:ICONS[0][1],tint:'#6699cc',size:48,globallyVisible:true});
  assert.equal(n.entryId,'a');
  assert.equal(n.pageId,'b');
  assert.deepEqual(n.texture,{src:ICONS[0][1],tint:'#6699CC'});
  assert.equal(n.global,true);
  assert.equal(n.x,11);
  assert.equal(n.iconSize,48);
});

test('creates native Journal + Page and one Note using explicit GM-only permission',async()=>{
  const before=createCalls;
  const {journal,note}=await createQuickMapNote({scene,at:{x:120,y:230},form:baseForm(),users:players});
  assert.equal(createCalls,before+1);
  assert.deepEqual(journal.ownership,{default:0});
  assert.equal(lastJournalData.pages[0].ownership.default,-1);
  assert.match(lastJournalData.pages[0].text.content,/&lt;danger&gt; &amp; clues/);
  assert.equal(note.entryId,journal.id);
  assert.equal(note.pageId,journal.pages[0].id);
  assert.equal(note.texture.tint,'#EDAB12');
  assert.equal(note.global,false);
});

test('specific player permissions applied to new Journal, GM never included',async()=>{
  const form=baseForm();
  form.visibility='specific';form['perm_p-1']='1';form['perm_p-2']='2';form['perm_g-1']='2';
  await createQuickMapNote({scene,at:{x:10,y:20},form,users:players});
  assert.deepEqual(lastJournalData.ownership,{default:0,'p-1':1,'p-2':2});
});

test('linking an existing Journal does not update or replace it',async()=>{
  const existing={id:'existing-123',name:'GM Secrets',ownership:{default:0},pages:[{id:'secret-page'}]};
  journalMap.set(existing.id,existing);
  const before=createCalls;
  const form=baseForm();form.existingJournal=existing.id;form.title='GM Pin';form.visibility='read';
  const {note,linkedExisting}=await createQuickMapNote({scene,at:{x:12,y:18},form,users:players});
  assert.equal(createCalls,before);
  assert.equal(linkedExisting,true);
  assert.equal(note.entryId,existing.id);
  assert.equal(note.pageId,undefined);
  assert.deepEqual(existing.ownership,{default:0});
});

test('failed pin creation preserves already-created Journal without deletion',async()=>{
  noteShouldFail=true;
  const before=createCalls;
  await assert.rejects(
    createQuickMapNote({scene,at:{x:20,y:30},form:baseForm(),users:players}),
    /new Journal "Old Warehouse" was kept/
  );
  assert.equal(createCalls,before+1);
  noteShouldFail=false;
});

test('image upload uses unique persistent module filename and returns URL',async()=>{
  uploadCalls=[];
  const file = new File(['image bytes'],'original.png',{type:'image/png'});
  const path=await uploadNewIcon(file);
  assert.equal(uploadCalls.length,1);
  assert.equal(uploadCalls[0][0],'stl-quick-map-notes');
  assert.equal(uploadCalls[0][1],'');
  assert.equal(uploadCalls[0][2].name,'map-note-Abc12345.png');
  assert.match(path,/storage\/stl-quick-map-notes\/map-note-Abc12345.png/);
});

test('failed upload cannot create a Journal or Note',async()=>{
  const before=createCalls;
  const form=baseForm();form.iconPreset='custom';
  await assert.rejects(createQuickMapNote({
    scene,at:{x:20,y:30},form,users:players,
    uploadedFile:{type:'image/png',size:1024},upload:async()=>{throw Error('upload failed');}
  }),/upload failed/);
  assert.equal(createCalls,before);
});

test('only GM can create; invalid title or mismatched existing Journal causes no data mutations',async()=>{
  const before=createCalls;
  game.user.isGM=false;
  await assert.rejects(createQuickMapNote({scene,at:{x:1,y:1},form:baseForm()}),/Only a GM/);
  game.user.isGM=true;
  const noTitle=baseForm();noTitle.title='';
  await assert.rejects(createQuickMapNote({scene,at:{x:1,y:1},form:noTitle}),/Enter a title/);
  const missing=baseForm();missing.existingJournal='does-not-exist';
  await assert.rejects(createQuickMapNote({scene,at:{x:1,y:1},form:missing}),/no longer exists/);
  assert.equal(createCalls,before);
});

test('quick tool arms next scene click, Escape cancels, and click presents icon/tint/upload dialog',async()=>{
  const boardEvents=new Map();
  const docEvents=new Map();
  const board={style:{cursor:'default'},
    addEventListener(name,fn){boardEvents.set(name,fn);},
    removeEventListener(name,fn){if(boardEvents.get(name)===fn)boardEvents.delete(name);}
  };
  globalThis.document={
    createElement(){return {innerHTML:''};},
    addEventListener(name,fn){docEvents.set(name,fn);},
    removeEventListener(name,fn){if(docEvents.get(name)===fn)docEvents.delete(name);}
  };
  canvas.app={canvas:board};
  canvas.canvasCoordinatesFromClient=point=>point;
  let receivedDialog=null;
  foundry.applications.api.DialogV2.input=async config=>{receivedDialog=config;return null;};
  const controls={tokens:{tools:{select:{order:0}}},notes:{tools:{select:{order:0}}}};
  listeners.get('getSceneControlButtons')(controls);
  controls.tokens.tools.stlQuickMapNote.onChange();
  assert.equal(board.style.cursor,'crosshair');
  assert.equal(boardEvents.has('pointerdown'),true);
  docEvents.get('keydown')({key:'Escape',preventDefault(){},stopPropagation(){}});
  assert.equal(board.style.cursor,'default');
  assert.equal(boardEvents.has('pointerdown'),false);
  controls.tokens.tools.stlQuickMapNote.onChange();
  const point={button:0,clientX:35,clientY:90,preventDefault(){},stopImmediatePropagation(){}};
  boardEvents.get('pointerdown')(point);
  await new Promise(setImmediate);
  assert.equal(boardEvents.has('pointerdown'),false);
  assert.equal(board.style.cursor,'default');
  assert.equal(receivedDialog.window.title,'Quick Map Note');
  assert.match(receivedDialog.content.innerHTML,/Upload image/);
  assert.match(receivedDialog.content.innerHTML,/Icon tint/);
  assert.match(receivedDialog.content.innerHTML,/Everyone sees the pin/);
});

test('module provenance excludes imported module journals but retains world and system imports', () => {
  const packs=new Map([
    ['tc-modern.locations',{metadata:{packageType:'module'}}],
    ['custom-world.notes',{metadata:{packageType:'world'}}],
    ['worldofdarkness.rules',{metadata:{packageType:'system'}}]
  ]);
  const modules=new Map([['tc-modern',{id:'tc-modern'}],['another-addon',{id:'another-addon'}]]);
  const check = j => isModuleSuppliedJournal(j,{packs,modules});
  assert.equal(check({id:'j1',_stats:{compendiumSource:'Compendium.tc-modern.locations.JournalEntry.ID123'}}),true);
  assert.equal(check({id:'j2',_source:{_stats:{compendiumSource:'Compendium.tc-modern.locations.JournalEntry.ID123'}}}),true);
  assert.equal(check({id:'j3',_stats:{compendiumSource:'Compendium.another-addon.notes.JournalEntry.ID'}}),true);
  assert.equal(check({id:'j4',_stats:{compendiumSource:'Compendium.custom-world.notes.JournalEntry.ID'}}),false);
  assert.equal(check({id:'j5',_stats:{compendiumSource:'Compendium.worldofdarkness.rules.JournalEntry.ID'}}),false);
  assert.equal(check({id:'j6',_stats:{compendiumSource:'JournalEntry.abc'}}),false);
  assert.equal(check({id:'j7',inCompendium:true}),true);
  assert.equal(check({id:'j8',flags:{core:{sourceId:'Compendium.tc-modern.locations.JournalEntry.ID'}}}),true);
});

test('module-generated flag excludes source entries but harmless module metadata never hides user journals', () => {
  const modules=new Map([['other-module',{}]]);
  const opts={packs:new Map(),modules};
  assert.equal(isModuleSuppliedJournal({id:'native',flags:{'other-module':{color:'#00ff00'}}},opts),false);
  assert.equal(isModuleSuppliedJournal({id:'quick',flags:{'stl-quick-map-notes':{createdWith:'0.1.1'}}},opts),true);
  assert.equal(isModuleSuppliedJournal({id:'other',flags:{'other-module':{createdBy:'other-module'}}},opts),true);
  assert.equal(isModuleSuppliedJournal({id:'other2',flags:{'other-module':{moduleCreated:true}}},opts),true);
  assert.equal(isModuleSuppliedJournal({id:'custom',flags:{world:{createdWith:'my-campaign'}}},opts),false);
});

test('existing Journal choices follow nested folder hierarchy and escape option text', () => {
  const root={id:'folder-root',name:'Campaign',ancestors:[]};
  const locations={id:'folder-loc',name:'Locations',ancestors:[root]};
  const people={id:'folder-ppl',name:'People',ancestors:[root]};
  const sub={id:'folder-sub',name:'Warehouses',ancestors:[locations,root]};
  const empty={id:'folder-empty',name:'Empty Folder',ancestors:[root]};
  const modules=new Map([['tc-modern',{}]]);
  const packs=new Map([['tc-modern.entries',{metadata:{packageType:'module'}}]]);
  const entries=[
    {id:'j-w',name:'Warehouse 2',folder:sub},
    {id:'j-p',name:'Zoe & <Co>',folder:people},
    {id:'j-l',name:'Warehouse 10',folder:sub},
    {id:'j-unfiled',name:'Unfiled Notes',folder:null},
    {id:'j-block',name:'Module Secret',folder:empty,_stats:{compendiumSource:'Compendium.tc-modern.entries.JournalEntry.abc'}},
    {id:'j-qmn',name:'Auto-generated Note',folder:people,flags:{'stl-quick-map-notes':{createdWith:'0.1.1'}}}
  ];
  const html=buildJournalOptions(entries,{folders:new Map(),packs,modules});
  const pos = text => html.indexOf(text);
  assert.ok(pos('Campaign')>=0);
  assert.ok(pos('Campaign')<pos('Locations'));
  assert.ok(pos('Locations')<pos('Warehouses'));
  assert.ok(pos('Warehouses')<pos('Warehouse 2'));
  assert.ok(pos('Warehouse 2')<pos('Warehouse 10'));
  assert.ok(pos('Warehouses')<pos('People') || pos('People')<pos('Locations'));
  assert.ok(pos('Unfiled') > pos('People'));
  assert.match(html, /<option value="" disabled>Campaign<\/option>/);
  assert.match(html, /<option value="j-p">(?:&nbsp;){8}Zoe &amp; &lt;Co&gt;<\/option>/);
  assert.match(html, /<option value="j-w">(?:&nbsp;){12}Warehouse 2<\/option>/);
  assert.doesNotMatch(html, /Module Secret|Empty Folder|Auto-generated Note/);
});

test('journal tree resolves folder IDs, handles cycles, and never creates selectable folder headers', () => {
  const a={id:'A',name:'A Folder',folder:'B'};
  const b={id:'B',name:'B Folder',folder:'A'};
  const folders=new Map([['A',a],['B',b]]);
  const html=buildJournalOptions([{id:'visible',name:'Journal',folder:'A'}],{folders,packs:new Map(),modules:new Map()});
  assert.match(html,/value="visible"/);
  assert.match(html,/A Folder/);
  assert.match(html,/B Folder/);
  assert.match(html,/<option value="" disabled>/);
  assert.equal((html.match(/value="visible"/g)??[]).length,1);
  assert.equal(buildJournalOptions([], {folders,packs:new Map(),modules:new Map()}),
    '<option value="" disabled>No eligible world Journals found</option>');
});

test('Journal picker rendered by the map dialog filters modules and displays nested folders', async () => {
  const folder={id:'folder-journal',name:'Locations & Clues',ancestors:[]};
  const own={id:'journal-own',name:'Own Journal',folder};
  const imported={id:'journal-module',name:'Module Journal',folder,
    _stats:{compendiumSource:'Compendium.tc-modern.entries.JournalEntry.MOD'}};
  const priorPacks=game.packs;
  const priorModules=game.modules;
  const priorFolders=game.folders;
  game.packs=new Map([['tc-modern.entries',{metadata:{packageType:'module'}}]]);
  game.modules=new Map([['tc-modern',{id:'tc-modern'}]]);
  game.folders=new Map([[folder.id,folder]]);
  journalMap.set(own.id,own);
  journalMap.set(imported.id,imported);
  let config=null;
  const oldInput=foundry.applications.api.DialogV2.input;
  foundry.applications.api.DialogV2.input=async options=>{config=options;return null;};
  const boardEvents=new Map();
  const board={style:{cursor:'default'},
    addEventListener(name,handler){boardEvents.set(name,handler);},
    removeEventListener(name,handler){if(boardEvents.get(name)===handler)boardEvents.delete(name);}
  };
  const oldDocument=globalThis.document;
  const oldApp=canvas.app;
  const oldConverter=canvas.canvasCoordinatesFromClient;
  globalThis.document={createElement(){return {innerHTML:''};},addEventListener(){},removeEventListener(){}};
  canvas.app={canvas:board};
  canvas.canvasCoordinatesFromClient=pos=>pos;
  try {
    const controls={tokens:{tools:{select:{order:1}}}};
    listeners.get('getSceneControlButtons')(controls);
    controls.tokens.tools.stlQuickMapNote.onChange();
    boardEvents.get('pointerdown')({button:0,clientX:20,clientY:30,preventDefault(){},stopImmediatePropagation(){}});
    await new Promise(setImmediate);
    assert.ok(config);
    assert.match(config.content.innerHTML,/Locations &amp; Clues/);
    assert.match(config.content.innerHTML,/value="journal-own"/);
    assert.doesNotMatch(config.content.innerHTML,/value="journal-module"/);
  } finally {
    foundry.applications.api.DialogV2.input=oldInput;
    globalThis.document=oldDocument;
    canvas.app=oldApp;
    canvas.canvasCoordinatesFromClient=oldConverter;
    game.packs=priorPacks;
    game.modules=priorModules;
    game.folders=priorFolders;
    journalMap.delete(own.id);
    journalMap.delete(imported.id);
  }
});


test('Rules Reference matching is specific and handles common naming variants', () => {
  for (const value of ['Rules Reference', 'M20 Rules Reference', 'M20 - Rules Reference',
    'Mage Rules Reference', 'Rules-Reference (Mage)', 'rules_reference']) {
    assert.equal(isRulesReferenceName(value), true, value);
  }
  for (const value of ['Campaign', 'Reference Notes', 'Rules for Magic',
    'Character Reference', 'Book of Rules']) {
    assert.equal(isRulesReferenceName(value), false, value);
  }
  assert.equal(isRulesReferenceJournal({name:'Rules Reference'}), true);
  assert.equal(isRulesReferenceJournal({name:'My Journal'}, [{name:'Rules Reference'}]), true);
  assert.equal(isRulesReferenceJournal({name:'Campaign'}, [{name:'House Rules'}]), false);
  assert.equal(isRulesReferenceJournal({name:'Spheres', _stats:{
    compendiumSource:'Compendium.m20-rules-reference.rulebook.JournalEntry.abc'
  }}), true);
  assert.equal(isRulesReferenceJournal({name:'Spheres', flags:{core:{
    sourceId:'Compendium.m20_rulesReference.pages.JournalEntry.abc'
  }}}), true);
  assert.equal(isRulesReferenceJournal({name:'Spheres', _stats:{
    compendiumSource:'Compendium.worldofdarkness.rules.JournalEntry.abc'
  }}), false);
});

test('existing Journal picker hides entire Rules Reference subtree even if provenance was stripped', () => {
  const folder={id:'camp',name:'Campaign',ancestors:[]};
  const library={id:'ref',name:'M20 Rules Reference',ancestors:[]};
  const hiddenSection={id:'ref-sub',name:'Spheres',ancestors:[library]};
  const otherSection={id:'custom-sub',name:'Spheres',ancestors:[folder]};
  const gameJournals=[
    {id:'lib1',name:'Correspondence',folder:hiddenSection},
    {id:'lib2',name:'Arete',folder:library},
    {id:'lib3',name:'Rules Reference Index',folder:null},
    {id:'lib4',name:'A Source Without a Folder',folder:null,_stats:{
      compendiumSource:'Compendium.m20-rules-reference.pages.JournalEntry.abc'
    }},
    {id:'keep1',name:'Eli Notes',folder:otherSection},
    {id:'keep2',name:'Campaign Reference Notes',folder:null},
    {id:'keep3',name:'House Rules',folder:folder}
  ];
  const opts={folders:new Map(),packs:new Map(),modules:new Map()};
  const html=buildJournalOptions(gameJournals,opts);
  assert.doesNotMatch(html,/Correspondence|Arete|Rules Reference Index|A Source Without a Folder/);
  assert.doesNotMatch(html,/M20 Rules Reference/);
  assert.match(html,/value="keep1"/);
  assert.match(html,/value="keep2"/);
  assert.match(html,/value="keep3"/);
  assert.match(html,/Campaign/);
  assert.match(html,/Spheres/);
  assert.ok(html.indexOf('Campaign') < html.indexOf('Eli Notes'));
});

test('Rules Reference-only folders leave no ghost headings or selectable journals', () => {
  const ref={id:'ref',name:'Rules Reference',ancestors:[]};
  const section={id:'ref-child',name:'Chapter One',ancestors:[ref]};
  const html=buildJournalOptions([{id:'rule',name:'Spheres',folder:section}],{
    folders:new Map(),packs:new Map(),modules:new Map()
  });
  assert.equal(html,'<option value="" disabled>No eligible world Journals found</option>');
});

// --- v0.1.4: User.query challenges, two player sections, native folders ---
const gm={id:'g-1',isGM:true,active:true,name:'GM'};
const alice={id:'p-1',isGM:false,active:true,viewedScene:'scene-123',name:'Alice'};
const bob={id:'p-2',isGM:false,active:true,viewedScene:'scene-123',name:'Bob'};
const playerCollection=new Map([[gm.id,gm],[alice.id,alice],[bob.id,bob]]);
playerCollection.activeGM=gm;
let folderCreates=0;
globalThis.Folder={async create(data){
  folderCreates++;
  const folder={id:`folder-${folderCreates}`,...data};
  game.folders.set(folder.id,folder);
  return folder;
}};
function usePlayerCollection() {
  game.user=gm;
  for (const [id,j] of journalMap) {
    if (j.flags?.['stl-quick-map-notes']?.playerMapJournal) journalMap.delete(id);
  }
  game.users=playerCollection;
  game.scenes=new Map([[scene.id,{...scene,active:true,dimensions:canvas.dimensions}]]);
  game.folders=new Map();
  game.packs=new Map();
  game.modules=new Map();
}
const playerForm=(scope='personal')=>({...baseForm(),playerScope:scope});

// Need to make sure player note author can edit, party can read but not modify,
// and nobody else gets a private note.
test('ownership presets: personal is private; party is readable but only author owns',()=>{
  assert.deepEqual(buildPlayerOwnership('personal',alice.id),{default:0,'p-1':3});
  assert.deepEqual(buildPlayerOwnership('party',alice.id),{default:2,'p-1':3});
  assert.throws(()=>buildPlayerOwnership('read',alice.id),/Invalid player/);
  assert.throws(()=>buildPlayerOwnership('personal',''),/Player identity/);
});

test('player dialog offers Personal and Shared with Party instead of GM Journal selection', async()=>{
  usePlayerCollection();
  game.user=alice;
  const oldInput=foundry.applications.api.DialogV2.input;
  const events=new Map();
  const board={style:{cursor:'default'}, addEventListener(name,cb){events.set(name,cb);},
    removeEventListener(name){events.delete(name);}};
  canvas.app={canvas:board};
  canvas.canvasCoordinatesFromClient=p=>p;
  let capture=null;
  foundry.applications.api.DialogV2.input=async config=>{capture=config;return null;};
  const controls={tokens:{tools:{select:{order:1}}}};
  listeners.get('getSceneControlButtons')(controls);
  try {
    controls.tokens.tools.stlQuickMapNote.onChange();
    events.get('pointerdown')({button:0,clientX:5,clientY:10,preventDefault(){},stopImmediatePropagation(){}});
    await new Promise(setImmediate);
    const html=capture.content.innerHTML;
    assert.match(html, /name="playerScope"/);
    assert.match(html, /Personal — only you and the GM/);
    assert.match(html, /Shared with Party — everyone can read/);
    assert.doesNotMatch(html,/Use an existing Journal|name="visibility"|Choose specific players/);
    assert.match(html, /name="description"/);
    assert.match(html,/Icon tint|Upload image/);
  }finally {foundry.applications.api.DialogV2.input=oldInput;game.user=gm;}
});

test('player GM-validation limits modes, scene, note content, paths and private Journal links',()=>{
  usePlayerCollection();
  const campaignScene=game.scenes.get(scene.id),at={x:22,y:24};
  const form=playerForm('personal');
  assert.equal(validatePlayerNoteRequest({scene:campaignScene,at,form,user:alice}),true);
  assert.equal(validatePlayerNoteRequest({scene:campaignScene,at,form:playerForm('party'),user:alice}),true);
  assert.throws(()=>validatePlayerNoteRequest({scene:campaignScene,at,form:{...form,playerScope:'read'},user:alice}),/choose Personal/i);
  assert.throws(()=>validatePlayerNoteRequest({scene:campaignScene,at,form:{...form,existingJournal:'gm-secret'},user:alice}),/not an existing Journal/);
  assert.throws(()=>validatePlayerNoteRequest({scene:campaignScene,at,form:{...form,description:'x'.repeat(10001)},user:alice}),/10,000/);
  assert.throws(()=>validatePlayerNoteRequest({scene:campaignScene,at:{x:900,y:90},form,user:alice}),/inside the Scene/);
  assert.throws(()=>validatePlayerNoteRequest({scene:campaignScene,at,form,user:gm}),/Invalid player/);
  assert.throws(()=>validatePlayerNoteRequest({scene:{...campaignScene,id:'other'},at,form,user:alice}),/Scene they are viewing/);
  for(const path of ['https://x.io/track.png','../secrets.png','//host/file.svg','file\\escape.png']){
    assert.equal(playerIconValid(path),false,path);
    assert.throws(()=>validatePlayerNoteRequest({scene:campaignScene,at,
      form:{...form,iconPreset:'custom',customPath:path},user:alice}),/valid map icon/);
  }
  assert.equal(playerIconValid('assets/icons/custom.svg'),true);
});

test('first personal note creates one Scene-named Journal with private Page and linked pin',async()=>{
  usePlayerCollection();folderCreates=0;
  const old=journalMap.size;
  const result=await createQuickMapNote({scene,at:{x:40,y:42},form:playerForm(),users:[alice,bob],requester:alice});
  assert.equal(journalMap.size,old+1);
  assert.equal(result.journal.name,'Maryland Heights');
  assert.deepEqual(result.journal.ownership,{default:2});
  assert.deepEqual(result.page.ownership,{default:0,[alice.id]:3});
  assert.equal(result.page.name,'Old Warehouse');
  assert.equal(result.page.flags['stl-quick-map-notes'].playerScope,'personal');
  assert.equal(result.journal.flags['stl-quick-map-notes'].playerMapSceneId,scene.id);
  assert.equal(lastJournalData.folder, 'folder-1');
  assert.equal(folderCreates,1);
  assert.deepEqual([...game.folders.values()].map(f=>f.name),['Party Map Notes']);
  assert.equal(result.note.entryId,result.journal.id);
  assert.equal(result.note.pageId,result.page.id);
});

test('shared and private notes become separate pages in same Scene journal',async()=>{
  const old=createCalls;
  const priorJournal=lastJournalData;
  const privatePage=[...journalMap.values()].find(j=>j.flags?.['stl-quick-map-notes']?.playerMapJournal).pages[0];
  const result=await createQuickMapNote({scene,at:{x:45,y:46},form:playerForm('party'),users:[alice,bob],requester:bob});
  assert.equal(createCalls,old,'reuse the original Journal');
  assert.equal(lastJournalData,priorJournal,'do not rewrite the existing Journal');
  assert.equal(folderCreates,1,'do not create additional folders');
  assert.equal(result.journal.name,'Maryland Heights');
  assert.deepEqual(result.journal.ownership,{default:2});
  assert.deepEqual(privatePage.ownership,{default:0,[alice.id]:3});
  assert.deepEqual(result.page.ownership,{default:2,[bob.id]:3});
  assert.equal(result.page.flags['stl-quick-map-notes'].playerCreated,bob.id);
  assert.equal(result.journal.pages.length,2);
  assert.equal(result.note.pageId,result.page.id);
  assert.notEqual(result.note.pageId,privatePage.id);
  const additional=await createQuickMapNote({scene,at:{x:47,y:48},form:playerForm('party'),users:[alice,bob],requester:alice});
  assert.equal(additional.journal.id,result.journal.id);
  assert.equal(additional.journal.pages.length,3);
});

test('simultaneous player notes serialize per-Scene and never create duplicate Journals',async()=>{
  usePlayerCollection();folderCreates=0;
  const before=createCalls;
  const notes=await Promise.all([
    createQuickMapNote({scene,at:{x:10,y:15},form:playerForm(),requester:alice,users:[alice,bob]}),
    createQuickMapNote({scene,at:{x:12,y:18},form:playerForm('party'),requester:bob,users:[alice,bob]})
  ]);
  assert.equal(folderCreates,1);
  assert.deepEqual([...game.folders.values()].map(f=>f.name),['Party Map Notes']);
  assert.equal((await ensurePlayerMapNotesFolder()).id,[...game.folders.values()][0].id);
  assert.equal(createCalls,before+1);
  assert.equal(notes[0].journal.id,notes[1].journal.id);
  assert.equal(notes[0].journal.pages.length,2);
  assert.notEqual(notes[0].note.pageId,notes[1].note.pageId);
  assert.deepEqual(notes[0].page.ownership,{default:0,[alice.id]:3});
  assert.deepEqual(notes[1].page.ownership,{default:2,[bob.id]:3});
});

test('another Scene with the same display name gets its own Journal by Scene ID',async()=>{
  usePlayerCollection();folderCreates=0;
  const first=await createQuickMapNote({scene,at:{x:20,y:25},form:playerForm('party'),requester:bob});
  const other={...scene,id:'a-different-scene'};
  const second=await createQuickMapNote({scene:other,at:{x:20,y:25},form:playerForm('personal'),requester:alice});
  assert.notEqual(first.journal.id,second.journal.id);
  assert.equal(first.journal.name,second.journal.name);
  assert.equal(first.journal.flags['stl-quick-map-notes'].playerMapSceneId,scene.id);
  assert.equal(second.journal.flags['stl-quick-map-notes'].playerMapSceneId,other.id);
  assert.equal(folderCreates,1);
});

test('concurrent notes on different scenes create only one Party Map Notes root',async()=>{
  usePlayerCollection();folderCreates=0;
  const other={...scene,id:'concurrent-scene',name:'Other Scene'};
  const notes=await Promise.all([
    createQuickMapNote({scene,at:{x:10,y:15},form:playerForm(),requester:alice}),
    createQuickMapNote({scene:other,at:{x:12,y:18},form:playerForm('party'),requester:bob})
  ]);
  assert.equal(folderCreates,1);
  assert.notEqual(notes[0].journal.id,notes[1].journal.id);
  assert.equal(notes[0].journal.folder,notes[1].journal.folder);
});

test('name collisions with ordinary Journals do not cause writes to GM data',async()=>{
  usePlayerCollection();folderCreates=0;
  const existing={id:'map-name-collision',name:scene.name,folder:'folder-1',pages:[{id:'gm-secret'}],
    ownership:{default:0}, flags:{world:{campaign:true}}};
  journalMap.set(existing.id,existing);
  const first=await createQuickMapNote({scene,at:{x:20,y:25},form:playerForm(),requester:alice});
  assert.notEqual(first.journal.id,existing.id);
  assert.deepEqual(existing.pages,[{id:'gm-secret'}]);
  journalMap.delete(existing.id);
});

test('manually changed parent permissions block new pages instead of exposing private notes',async()=>{
  usePlayerCollection();folderCreates=0;
  const first=await createQuickMapNote({scene,at:{x:20,y:25},form:playerForm(),requester:alice});
  const journal=first.journal;
  const before=journal.pages.length;
  journal.ownership[alice.id]=3;
  await assert.rejects(createQuickMapNote({scene,at:{x:21,y:26},form:playerForm('party'),requester:bob}),/permissions changed/);
  assert.equal(journal.pages.length,before);
  delete journal.ownership[alice.id];
  journal.ownership.default=0;
  await assert.rejects(createQuickMapNote({scene,at:{x:22,y:26},form:playerForm('party'),requester:bob}),/permissions changed/);
  assert.equal(journal.pages.length,before);
});

test('failed pin placement retains a newly added page for GM recovery',async()=>{
  usePlayerCollection();folderCreates=0;
  const first=await createQuickMapNote({scene,at:{x:20,y:25},form:playerForm(),requester:alice});
  const journal=first.journal;
  noteShouldFail=true;
  try {
    await assert.rejects(createQuickMapNote({scene,at:{x:21,y:26},form:playerForm('party'),requester:bob}),/Journal Page.*was kept/);
    assert.equal(journal.pages.length,2);
    assert.deepEqual(journal.pages[1].ownership,{default:2,[bob.id]:3});
  } finally {noteShouldFail=false;}
});

test('player request cannot link arbitrary existing GM Journal or choose GM-only visibility',async()=>{
  usePlayerCollection();
  const secret={id:'gm-secret',name:'GM Plans',testUserPermission:()=>false};
  journalMap.set(secret.id,secret);
  const form={...playerForm('personal'),existingJournal:'gm-secret',visibility:'read'};
  const before=createCalls;
  try{
    await assert.rejects(createQuickMapNote({scene,at:{x:20,y:20},form,requester:alice}),/not existing Journals/);
    assert.equal(createCalls,before);
  }finally{journalMap.delete(secret.id);}
});

test('player-uploaded icons reject spoofed MIME and oversized data',async()=>{
  const pngBytes=Uint8Array.from([137,80,78,71,13,10,26,10,0,0,0,0]);
  const encoded=await encodePlayerImage(new File([pngBytes],'ok.png',{type:'image/png'}));
  const restored=decodePlayerImage(encoded);
  assert.deepEqual(new Uint8Array(await restored.arrayBuffer()),pngBytes);
  await assert.rejects(encodePlayerImage(new File(['invalid'],'bad.png',{type:'image/png'})),/not a valid image/);
  await assert.rejects(encodePlayerImage(new File([new Uint8Array(512*1024+1)],'big.png',{type:'image/png'})),/512 KB/);
  assert.throws(()=>decodePlayerImage({type:'image/png',encoded:btoa('invalid')}),/failed size or image validation/);
});

test('player query is private to active GM; identity requires matching targeted challenge',async()=>{
  usePlayerCollection();game.user=alice;
  const original=gm.query;
  let outgoing=null;
  gm.query=async(name,payload,opts)=>{
    outgoing={name,payload,opts};
    const verify=verifyPlayerNoteQuery({requestId:payload.requestId,challenge:'d'.repeat(64),sceneId:scene.id});
    assert.equal(verify.challenge,'d'.repeat(64));
    assert.equal(verifyPlayerNoteQuery({requestId:payload.requestId,challenge:'d'.repeat(64),sceneId:scene.id}),null,'challenge one-time only');
    return {ok:true,noteId:'id1',journalId:'journal1',icon:ICONS[0][1],tint:'#FFFFFF'};
  };
  try {
    const input={...playerForm('party'),description:'PRIVATE JOURNAL TEXT'};
    const res=await submitPlayerNoteRequest({scene,at:{x:30,y:30},form:input});
    assert.equal(res.noteId,'id1');
    assert.equal(outgoing.name,'stl-quick-map-notes.createPlayerNote');
    assert.equal(outgoing.payload.requesterId,alice.id);
    assert.equal(outgoing.payload.request.form.description,'PRIVATE JOURNAL TEXT');
    assert.equal(outgoing.payload.request.form.playerScope,'party');
    assert.equal(outgoing.payload.request.requesterId,undefined);
    assert.equal(CONFIG.queries['stl-quick-map-notes.verifyPlayerNote'],verifyPlayerNoteQuery);
    assert.equal(verifyPlayerNoteQuery({requestId:outgoing.payload.requestId,challenge:'d'.repeat(64),sceneId:scene.id}),null);
  }finally {game.user=gm;gm.query=original;}
});

test('GM handles verified request and places shared note; fake identity cannot be claimed',async()=>{
  usePlayerCollection();game.user=alice;
  const oldGmQuery=gm.query,oldAliceQuery=alice.query,oldBobQuery=bob.query;
  let counter=0;
  gm.query=async(name,payload)=>{
    counter++;
    const prev=game.user;game.user=gm;
    const reply=await handlePlayerNoteQuery(payload);
    game.user=prev;
    return reply;
  };
  alice.query=async(name,payload)=>{
    assert.equal(name,'stl-quick-map-notes.verifyPlayerNote');
    const prev=game.user;game.user=alice;
    const reply=verifyPlayerNoteQuery(payload);
    game.user=prev;
    return reply;
  };
  bob.query=async()=>null;
  try {
    const before=createCalls;
    const result=await submitPlayerNoteRequest({scene,at:{x:11,y:12},form:playerForm('party')});
    assert.equal(result.ok,true);
    assert.equal(createCalls,before+1);
    assert.equal(lastJournalData.ownership.default,2);
    assert.equal(lastJournalData.ownership[alice.id],undefined);
    assert.deepEqual(lastJournalData.pages[0].ownership,{default:2,[alice.id]:3});
    assert.ok(result.pageId);
    assert.equal(counter,1);
    const fake=await handlePlayerNoteQuery({requesterId:bob.id,requestId:'b'.repeat(64),
      request:{sceneId:scene.id,at:{x:22,y:22},form:playerForm('party'),image:null}});
    assert.equal(fake.ok,false);
  }finally{game.user=gm;gm.query=oldGmQuery;alice.query=oldAliceQuery;bob.query=oldBobQuery;}
});

test('GM rejects a forged player request before creating any folder or Journal',async()=>{
  usePlayerCollection();folderCreates=0;game.user=gm;
  const before=createCalls;
  bob.query=async()=>null;
  const result=await handlePlayerNoteQuery({requesterId:bob.id,requestId:'e'.repeat(64),
    request:{sceneId:scene.id,at:{x:3,y:4},form:playerForm('personal'),image:null}});
  assert.equal(result.ok,false);
  assert.match(result.error,/verification failed/);
  assert.equal(createCalls,before);
  assert.equal(folderCreates,0);
  delete bob.query;
});
